#include <windows.h>
#include "icb_gui.h"
#include <stdio.h>


#define WIDTH 800
#define HEIGHT 600
#define ROAD_LEFT_BOUND 200
#define ROAD_RIGHT_BOUND (WIDTH - 200)
#define MAX_MERMILER 50
#define MAX_ARKAPLAN 7 // Arka plan say s 
#define MAX_PATLAMALAR 15
#define MAX_DUSMAN 10 // Ayn  anda ekranda en fazla 5 d  man olacak.
#define MAX_DUSMAN_MERMISI 2

typedef struct {
	int x, y;
	bool aktif;
} Mermi;

typedef struct {
	int x, y;
	int aktif;
	int sure;
} Patlama;

typedef struct {
	int x, y;
	bool aktif;
} DusmanMermisi;

typedef struct {
	int x, y;
	int width, height;
	int type;  // 12 farkl  d  man
	bool aktif;
	int hiz;  // H z n  belirlemek i in
	int hareketTipi; // 0 = d z, 1 = h zl , 2 = zikzak, 3 = ate  eden
	int hareketYon; // Zikzak hareket i in y n (-1 veya 1)
	int can;
} Dusman;

Patlama patlamalar[MAX_PATLAMALAR];
Mermi mermiler[MAX_MERMILER];
Dusman dusmanlar[MAX_DUSMAN];  // D  manlar  takip eden dizi
DusmanMermisi dusmanMermileri[MAX_DUSMAN_MERMISI];

ICBYTES motor, arkaplan, enemySprites[12], rocket, patlama, yildiz, araba, motorSol, motorSag, mayin, ufakTop;
ICBYTES maviyildiz, kalkan, bilgilendirme; // Yeni sprite de i kenleri


bool maviyildizGorunur = false;
bool kalkanAktif = false;
int maviyildizX, maviyildizY;
int kalkanSure = 0; // Kalkan s resi (120 frame = 2 saniye)

int FRM1, BTN;
int skorGosterge;
int Motorx = WIDTH / 2, Motory = HEIGHT - 100;
bool oyunBasladi = false;
int skor = 0;
int enemySpawnTimer = 0;
int mevcutArkaPlan = 1; //  u anki arka plan numaras 
int yildizSure = 0;
int motorYon = 0;
int SLE, LVL;
bool yildizAktif = false;
bool keys[256] = { false };
bool atesEdildi = false;
int level2GostermeSuresi = 3;
bool yildizGorunur = false; // Y ld z ekranda m ?
int yildizX, yildizY; // Y ld z n koordinatlar 


void oyunBaslat(void* param);
void dusmanlariBaslat();
void KeyDown(int key);
void KeyUp(int key);
void KeyPressKontrol();
void oyunOynamaFonk(void* param);
void dusmanOlustur();
void roketAtesle();
void mermileriGuncelle();
void ekranYenile();
void oyunBitti();
void carpismaKontrol();
void roketCarpismaKontrol();
void skorGoster();
void skorGuncelle();
void levelYaziGoster();
DWORD WINAPI KeyListenerThread(LPVOID param);

void ICGUI_Create() {
	ICG_MWSize(WIDTH, HEIGHT);
	ICG_MWTitle("Action Fighter");
	ICG_MWColor(255, 255, 255);
}

void SesCal(const char* dosyaAdi) {
	PlaySound(dosyaAdi, NULL, SND_FILENAME | SND_ASYNC);
}


void SesEfektCal(const char* dosyaAdi) {
	char command[128];
	sprintf_s(command, "play %s", dosyaAdi);
	mciSendString(command, NULL, 0, NULL);
}

void oyunBilgilendirmeEkrani() {
	ReadImage("bilgilendirme.bmp", bilgilendirme);

	DisplayImage(FRM1, bilgilendirme);

	while (!keys[VK_RETURN]) { // ENTER'a bas lmas n  bekle
		Sleep(100);
	}
}


void oyunBaslat(void* param) {

	oyunBilgilendirmeEkrani(); //  nce bilgilendirme ekran n  g ster

	oyunBasladi = true;

	PlaySound("03-Ground-Level_1.wav", NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);

	dusmanlariBaslat();

	char dosyaAdi[10];
	sprintf_s(dosyaAdi, sizeof(dosyaAdi), "%d.bmp", mevcutArkaPlan);
	ReadImage(dosyaAdi, arkaplan);

	ReadImage("Motor.bmp", motor);
	ReadImage("MotorSaga.bmp", motorSag);
	ReadImage("MotorSola.bmp", motorSol);
	ReadImage("Rocket.bmp", rocket);
	ReadImage("patlamaEfekt.bmp", patlama);
	ReadImage("yildiz.bmp", yildiz);
	ReadImage("Araba.bmp", araba);
	ReadImage("mayin.bmp", mayin);
	// ReadImage("ufakTop.bmp", ufakTop); //
	ReadImage("yeniMermi.bmp", ufakTop);

	ReadImage("maviyildiz.bmp", maviyildiz);
	ReadImage("kalkan.bmp", kalkan);


	ReadImage("dusmanAraba1.bmp", enemySprites[0]);
	ReadImage("dusmanAraba2.bmp", enemySprites[1]);
	ReadImage("dusmanMotor.bmp", enemySprites[2]);
	ReadImage("dusmanAraba4.bmp", enemySprites[3]);
	ReadImage("dusmanAraba3.bmp", enemySprites[4]);
	ReadImage("dusmanAraba5.bmp", enemySprites[5]);



	PasteNon0(motor, Motorx, Motory, arkaplan);
	DisplayImage(FRM1, arkaplan);

	CreateThread(NULL, 0, KeyListenerThread, NULL, 0, NULL);
	CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)oyunOynamaFonk, NULL, 0, NULL);
}

void KeyDown(int key) {
	keys[key] = true;

	if (key == VK_SPACE && !atesEdildi) {
		roketAtesle();
		atesEdildi = true;
	}
}

void KeyUp(int key) {
	keys[key] = false;

	if (key == VK_SPACE) {
		atesEdildi = false;
	}
}

void KeyPressKontrol() {
	static int hiz = 5;

	// E er sa a gitme tu una bas ld ysa ve yol s n r n  ge miyorsa
	if (keys[VK_RIGHT] && Motorx < ROAD_RIGHT_BOUND - 50) {
		Motorx += hiz;
		motorYon = 1;

		// E er araba formundaysa, motor sprite yerine araba sprite g ster
		if (yildizAktif) {
			PasteNon0(araba, Motorx, Motory, arkaplan);
		}
		else {
			PasteNon0(motorSag, Motorx, Motory, arkaplan);
		}
	}
	// E er sola gitme tu una bas ld ysa ve yol s n r n  ge miyorsa
	else if (keys[VK_LEFT] && Motorx > ROAD_LEFT_BOUND) {
		Motorx -= hiz;
		motorYon = -1;

		if (yildizAktif) {
			PasteNon0(araba, Motorx, Motory, arkaplan);
		}
		else {
			PasteNon0(motorSol, Motorx, Motory, arkaplan);
		}
	}
	// E er hi bir tu a bas lm yorsa
	else {
		motorYon = 0;

		if (yildizAktif) {
			PasteNon0(araba, Motorx, Motory, arkaplan);
		}
		else {
			PasteNon0(motor, Motorx, Motory, arkaplan);
		}
	}
}

void dusmanMermiAtesle(int dusmanX, int dusmanY) {
	for (int i = 0; i < MAX_DUSMAN_MERMISI; i++) {
		if (!dusmanMermileri[i].aktif) {
			dusmanMermileri[i].x = dusmanX + 10;
			dusmanMermileri[i].y = dusmanY + 30;
			dusmanMermileri[i].aktif = true;
			break;
		}
	}
}

void dusmanMermileriniGuncelle() {
	for (int i = 0; i < MAX_DUSMAN_MERMISI; i++) {
		if (dusmanMermileri[i].aktif) {
			dusmanMermileri[i].y += 5;  // D  man mermisi a a   do ru ilerler

			// Ekrandan   k nca mermiyi temizle
			if (dusmanMermileri[i].y > HEIGHT) {
				dusmanMermileri[i].aktif = false;
			}
		}
	}
}

void roketAtesle() {
	if (!yildizAktif) {
		// ?? Motor formundayken TEK MERM  ate leme
		for (int j = 0; j < MAX_MERMILER; j++) {
			if (!mermiler[j].aktif) {
				mermiler[j].x = Motorx + 20;
				mermiler[j].y = Motory - 10;
				mermiler[j].aktif = true;
				break;
			}
		}
	}
	else {
		// ?? Araba formundayken HER ZAMAN 2 MERM  ate leme
		int ilkMermiIndex = -1;
		int ikinciMermiIndex = -1;

		//  lk bo  mermiyi bul
		for (int j = 0; j < MAX_MERMILER; j++) {
			if (!mermiler[j].aktif) {
				if (ilkMermiIndex == -1) {
					ilkMermiIndex = j;
				}
				else {
					ikinciMermiIndex = j;
					break;  //  ki bo  slot buldu umuzda   k
				}
			}
		}

		// E er iki bo  mermi bulduysak,   FT MERM  ATE LE
		if (ilkMermiIndex != -1 && ikinciMermiIndex != -1) {
			// Sol roket
			mermiler[ilkMermiIndex].x = Motorx + 10;
			mermiler[ilkMermiIndex].y = Motory - 10;
			mermiler[ilkMermiIndex].aktif = true;

			// Sa  roket
			mermiler[ikinciMermiIndex].x = Motorx + 30;
			mermiler[ikinciMermiIndex].y = Motory - 10;
			mermiler[ikinciMermiIndex].aktif = true;
		}
	}
}

void mermileriGuncelle() {
	for (int i = 0; i < MAX_MERMILER; i++) {
		if (mermiler[i].aktif) {
			mermiler[i].y -= 10;
			if (mermiler[i].y < 0) {
				mermiler[i].aktif = false;
			}
		}
	}
}
void dusmanlariBaslat() {
	for (int i = 0; i < MAX_DUSMAN; i++) {
		dusmanlar[i].aktif = false;
	}
}

void dusmanOlustur() {
	enemySpawnTimer++;
	if (enemySpawnTimer > 30) {
		enemySpawnTimer = 0;

		int aktifDusmanSayisi = 0;
		for (int i = 0; i < MAX_DUSMAN; i++) {
			if (dusmanlar[i].aktif) {
				aktifDusmanSayisi++;
			}
		}

		if (aktifDusmanSayisi < MAX_DUSMAN - 1) {
			for (int i = 0; i < MAX_DUSMAN; i++) {
				if (!dusmanlar[i].aktif) {

					// *Araba modundaysa b y k d  manlar  (4,5) daha s k  ret*
					int yeniType;
					if (yildizAktif) {
						yeniType = (rand() % 3) + 3;  // Se im 3-5 aras nda olur (B y k ara lar dahil)
					}
					else {
						yeniType = rand() % 4;  // Se im 0-3 aras nda olur (K   k ara lar)
					}

					dusmanlar[i].type = yeniType;
					dusmanlar[i].x = ROAD_LEFT_BOUND + (rand() % (ROAD_RIGHT_BOUND - ROAD_LEFT_BOUND));
					dusmanlar[i].y = -50;

					dusmanlar[i].hareketTipi = rand() % 3;
					dusmanlar[i].hiz = (dusmanlar[i].hareketTipi == 1) ? 7 : 3;

					if (dusmanlar[i].hareketTipi == 2) {
						dusmanlar[i].hareketYon = (rand() % 2 == 0) ? -1 : 1;
					}

					// **B y k d  manlar (4,5) i in can 3 olarak ayarland **
					if (yeniType >= 4) {
						dusmanlar[i].can = 3;
					}
					else {
						dusmanlar[i].can = 1;
					}

					dusmanlar[i].aktif = true;

					break;
				}
			}
		}
	}
}






void dusmanlariGuncelle() {
	static int atesZamani = 0;
	atesZamani++;

	for (int i = 0; i < MAX_DUSMAN; i++) {
		if (dusmanlar[i].aktif) {
			switch (dusmanlar[i].hareketTipi) {
			case 0:  // D z hareket eden d  man
				dusmanlar[i].y += dusmanlar[i].hiz;
				break;

			case 1:  // H zl  hareket eden d  man
				dusmanlar[i].y += dusmanlar[i].hiz + 2;
				break;

			case 2:  // Zikzak  izen d  man
				dusmanlar[i].y += dusmanlar[i].hiz;
				dusmanlar[i].x += dusmanlar[i].hareketYon * 5;
				if (dusmanlar[i].x < ROAD_LEFT_BOUND || dusmanlar[i].x > ROAD_RIGHT_BOUND) {
					dusmanlar[i].hareketYon *= -1;  // Y n  tersine  evir
				}
				break;
			}

			// Ekrandan   kan d  man  temizle
			if (dusmanlar[i].y > HEIGHT + 50) {
				dusmanlar[i].aktif = false;

			}

			// D  man ate  mekanizmas  (sadece araba d n   m nden sonra)
			if (yildizAktif && atesZamani % 1000 == 0) { // Daha seyrek ate  etsin
				for (int j = 0; j < (rand() % 2) + 1; j++) { // 1 veya 2 mermi ats n
					for (int k = 0; k < MAX_MERMILER; k++) {
						if (!mermiler[k].aktif) {
							mermiler[k].x = dusmanlar[i].x + 10;
							mermiler[k].y = dusmanlar[i].y + 20;
							mermiler[k].aktif = true;
							break;
						}
					}
				}
			}
		}
	}
}


void dusmanMermisiCarpismaKontrol() {

	if (kalkanAktif) return; // Kalkan aktifse  arp  may  engelle


	int motorWidth = 20, motorHeight = 20;
	for (int i = 0; i < MAX_DUSMAN_MERMISI; i++) {
		if (dusmanMermileri[i].aktif) {
			if (Motorx + motorWidth > dusmanMermileri[i].x &&
				Motorx < dusmanMermileri[i].x + 10 &&
				Motory + motorHeight > dusmanMermileri[i].y &&
				Motory < dusmanMermileri[i].y + 10) {

				// Oyuncu vuruldu
				oyunBitti();
			}
		}
	}
}



void carpismaKontrol() {

	if (kalkanAktif) return; // Kalkan aktifse  arp  may  engelle


	int motorWidth = 20, motorHeight = 20;
	for (int i = 0; i < MAX_DUSMAN; i++) {
		if (dusmanlar[i].aktif) {
			int dusmanWidth = 20, dusmanHeight = 20; // Hitbox k   lt ld 
			if (Motorx + motorWidth > dusmanlar[i].x && Motorx < dusmanlar[i].x + dusmanWidth &&
				Motory + motorHeight > dusmanlar[i].y && Motory < dusmanlar[i].y + dusmanHeight) {
				oyunBitti();
			}
		}
	}
}

void roketCarpismaKontrol() {
	int roketWidth = 5, roketHeight = 5;
	for (int i = 0; i < MAX_MERMILER; i++) {
		if (mermiler[i].aktif) {
			for (int j = 0; j < MAX_DUSMAN; j++) {
				if (dusmanlar[j].aktif) {
					int dusmanWidth = 30, dusmanHeight = 30;
					if (mermiler[i].x + roketWidth > dusmanlar[j].x &&
						mermiler[i].x < dusmanlar[j].x + dusmanWidth &&
						mermiler[i].y + roketHeight > dusmanlar[j].y &&
						mermiler[i].y < dusmanlar[j].y + dusmanHeight) {

						// D  man n can n  azalt
						dusmanlar[j].can--;

						// E er can  0 olursa d  man  yok et
						if (dusmanlar[j].can <= 0) {
							dusmanlar[j].aktif = false;

							// B y k spriteli d  man 20 puan, di erleri 10 puan verir
							if (dusmanlar[j].type == 1 || dusmanlar[j].type == 3 || dusmanlar[j].type == 5) {
								skor += 20;
							}
							else {
								skor += 10;
							}

							skorGuncelle();

							// Patlama efekti ekle
							for (int k = 0; k < MAX_PATLAMALAR; k++) {
								if (!patlamalar[k].aktif) {
									patlamalar[k].x = dusmanlar[j].x;
									patlamalar[k].y = dusmanlar[j].y;
									patlamalar[k].aktif = true;
									patlamalar[k].sure = 10;
									break;
								}
							}
						}

						// Mermi her durumda yok edilir
						mermiler[i].aktif = false;
						break;
					}
				}
			}
		}
	}
}






void dusmanAtesKontrol() {
	if (yildizAktif) {
		for (int i = 0; i < MAX_DUSMAN; i++) {
			if (dusmanlar[i].aktif && rand() % 3 == 0) {
				dusmanMermiAtesle(dusmanlar[i].x, dusmanlar[i].y);
			}
		}
	}
}

void skorGuncelle() {
	skorGoster();

	if (skor >= 150 && !yildizAktif) { // 15 d  man  ld r l nce d n   m
		yildizAktif = true;
		yildizSure = 500;  // 500 d ng  boyunca etkili olacak


	}
}

void skorGoster() {

	ICG_SetWindowText(SLE, "Skor: ");
	ICG_printf(SLE, "%d ", skor);
}

void levelYaziGoster() {

	ICG_SetWindowText(LVL, "");
	ICG_printf(LVL, "Level 2");

}

void arkaPlaniDegistir() {
	mevcutArkaPlan++;
	if (mevcutArkaPlan > MAX_ARKAPLAN) {
		mevcutArkaPlan = 1;
	}

	char dosyaAdi[10];
	sprintf_s(dosyaAdi, sizeof(dosyaAdi), "%d.bmp", mevcutArkaPlan);
	ReadImage(dosyaAdi, arkaplan);

	//Sleep(10); // arkaplan  yava latmak i in
}

void yildizOlustur() {
	if (!yildizGorunur && rand() % 200 < 3) {  // Daha az y ld z   kar (%1.5 ihtimalle)
		yildizX = ROAD_LEFT_BOUND + rand() % (ROAD_RIGHT_BOUND - ROAD_LEFT_BOUND); // Yolda rastgele bir konum
		yildizY = Motory - 400; // Oyuncunun biraz  n nde ( st nde) olu tur
		yildizGorunur = true;
		yildizSure = 300; // Y ld z 300 frame boyunca g r n r
	}
}

void maviyildizOlustur() {
	if (!maviyildizGorunur && rand() % 700 < 2) {
		maviyildizX = ROAD_LEFT_BOUND + rand() % (ROAD_RIGHT_BOUND - ROAD_LEFT_BOUND); // Rastgele yol konumu
		maviyildizY = -50; // Ekran n  st nden gelmeye ba las n
		maviyildizGorunur = true;
	}
}



void yildizCarpismaKontrol() {
	if (yildizGorunur) {
		if (Motorx < yildizX + 30 && Motorx + 50 > yildizX &&
			Motory < yildizY + 30 && Motory + 50 > yildizY) {

			skor += 20; // 20 Puan Ekle
			yildizGorunur = false; // Y ld z kaybolsun
		}
	}
}

void maviyildizCarpismaKontrol() {
	if (maviyildizGorunur) {
		if (Motorx < maviyildizX + 30 && Motorx + 50 > maviyildizX &&
			Motory < maviyildizY + 30 && Motory + 50 > maviyildizY) {

			maviyildizGorunur = false; // Y ld z kaybolsun
			kalkanAktif = true; // Kalkan a 
			kalkanSure = 120; // 2 saniye boyunca aktif

		}
	}
}


void yildizHareket() {
	if (yildizGorunur) {
		yildizY += 3; // Y ld z n d  me h z 

		// E er y ld z ekran n alt na d  erse yok olsun
		if (yildizY > HEIGHT) {
			yildizGorunur = false;
		}
	}
}


void maviyildizHareket() {
	if (maviyildizGorunur) {
		maviyildizY += 3; // Yava  a a a   insin

		if (maviyildizY > HEIGHT) {
			maviyildizGorunur = false; // Ekrandan   k nca kaybolsun
		}
	}
}


void ekranYenile() {
	arkaPlaniDegistir();
	skorGuncelle();

	if (yildizAktif) {
		PasteNon0(araba, Motorx, Motory, arkaplan);
	}
	else {
		if (motorYon > 0) {
			PasteNon0(motorSag, Motorx, Motory, arkaplan);
		}
		else if (motorYon < 0) {
			PasteNon0(motorSol, Motorx, Motory, arkaplan);
		}
		else {
			PasteNon0(motor, Motorx, Motory, arkaplan);
		}
	}

	for (int i = 0; i < MAX_MERMILER; i++) {
		if (mermiler[i].aktif) {
			if (yildizAktif) {
				PasteNon0(rocket, mermiler[i].x, mermiler[i].y, arkaplan);
			}
			else {
				PasteNon0(ufakTop, mermiler[i].x, mermiler[i].y, arkaplan);
			}
		}
	}

	for (int i = 0; i < MAX_DUSMAN; i++) {
		if (dusmanlar[i].aktif && dusmanlar[i].type >= 0 && dusmanlar[i].type < 6) {
			// *Hatal  type de erlerini render etme*
			PasteNon0(enemySprites[dusmanlar[i].type], dusmanlar[i].x, dusmanlar[i].y, arkaplan);
		}
		else {
			dusmanlar[i].aktif = false;  // *Hatal  d  man  devre d    b rak*
		}
	}

	for (int i = 0; i < MAX_DUSMAN_MERMISI; i++) {
		if (dusmanMermileri[i].aktif) {
			PasteNon0(mayin, dusmanMermileri[i].x, dusmanMermileri[i].y, arkaplan);
		}
	}

	for (int i = 0; i < MAX_PATLAMALAR; i++) {
		if (patlamalar[i].aktif) {
			PasteNon0(patlama, patlamalar[i].x, patlamalar[i].y, arkaplan);
			patlamalar[i].sure--;
			if (patlamalar[i].sure <= 0) {
				patlamalar[i].aktif = 0;
			}
		}
	}

	if (yildizGorunur) {
		PasteNon0(yildiz, yildizX, yildizY, arkaplan); // Y ld z ekrana  iz
	}

	// Yeni y ld z olu tur

	if (yildizGorunur) {
		yildizSure--;
		if (yildizSure <= 0) {
			yildizGorunur = false; // S re dolunca y ld z kaybolsun
		}
	}



	if (maviyildizGorunur) {
		PasteNon0(maviyildiz, maviyildizX, maviyildizY, arkaplan);
	}


	if (kalkanAktif) {
		PasteNon0(kalkan, Motorx, Motory, arkaplan);
	}


	// YILDIZ AKT FSE VEYA LEVEL 2 S RES  DEVAM ED YORSA "LEVEL 2" YAZISINI G STER

	DisplayImage(FRM1, arkaplan);

	if (yildizAktif) {
		PasteNon0(araba, Motorx, Motory, arkaplan);
		levelYaziGoster(); // Y ld z aktifse Level 2 g ster
	}
	else {
		ICG_SetWindowText(LVL, " ");
		ICG_printf(LVL, "Level 1");// Y ld z etkisi bitince Level 1 g ster
	}
	skorGoster();
}


void oyunBitti() {
	SesCal("09-Game-Over.wav");
	ReadImage("gameovernew.bmp", arkaplan);
	DisplayImage(FRM1, arkaplan);

	skorGoster();

	Sleep(3000);
	exit(0);
}



void oyunOynamaFonk(void* param) {
	SLE = ICG_SLEditBorder(10, 13, 90, 50, "skor");
	LVL = ICG_SLEditBorder(10, 50, 90, 50, "Level 1");

	while (oyunBasladi) {

		KeyPressKontrol();
		mermileriGuncelle();
		dusmanlariGuncelle();
		dusmanMermileriniGuncelle();
		carpismaKontrol();
		roketCarpismaKontrol();
		dusmanMermisiCarpismaKontrol();
		ekranYenile();
		dusmanOlustur();
		dusmanAtesKontrol();
		yildizCarpismaKontrol();
		maviyildizCarpismaKontrol();  // *?? Bunu eklemelisin!*
		yildizOlustur();
		maviyildizOlustur(); // *Bu sat r  ekledik!*  
		yildizHareket();
		maviyildizHareket(); // *Mavi y ld z n da hareket etmesini sa la*

		if (yildizAktif) {
			yildizSure--;
			if (yildizSure <= 0) {
				yildizAktif = false;

			}
		}

		if (kalkanSure > 0) {
			kalkanSure--;
			if (kalkanSure <= 0) {
				kalkanAktif = false; // Kalkan s resi doldu

			}
		}

		Sleep(15);
	}


}

DWORD WINAPI KeyListenerThread(LPVOID param) {
	while (oyunBasladi) {
		for (int key = 0; key < 256; key++) {
			if (keys[key] && (GetAsyncKeyState(key) & 0x8000) == 0) {
				KeyUp(key);
			}
		}
		Sleep(10);
	}
	return 0;
}

void ICGUI_main() {
	SesCal("02-Your-Mission_1.wav");
	ReadImage("girisEkran.bmp", arkaplan);
	FRM1 = ICG_FrameMedium(5, 5, WIDTH, HEIGHT);

	BTN = ICG_TButton(350, 500, 100, 50, "START", oyunBaslat, NULL);
	DisplayImage(FRM1, arkaplan);

	ICG_SetOnKeyPressed(KeyDown);
}