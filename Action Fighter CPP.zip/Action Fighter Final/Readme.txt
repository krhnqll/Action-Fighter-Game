Action Fighter drive linki 

https://drive.google.com/file/d/1oJuXPTIxFcuVJZJz_lpH_h2BK5TPVy7l/view?usp=drive_linki

Action Fighter, hızlı tempolu bir aksiyon oyunudur. Oyuncu, başlangıçta bir motosiklet sürerken, düşman araçları vurarak ve ödülleri alarak skor toplar. 150 puana ulaşıldığında motosikletten araca dönüş gerçekleşir ve çift roket atma yeteneği kazanılır.

🎮 Oynanış
	•	Sağ / Sol Ok Tuşları → Aracı hareket ettir
	•	Boşluk (Space) Tuşu → Roket ateşle
	•	150 Skor → Motosikletten araca dönüş ve çift roket atışı
	•	Sarı Yıldız Toplama → +20 puan kazan
	•	Düşman Tehlikeleri →
	•	Düşman araçlara çarparsan oyun biter
	•	Düşman roketlerine çarparsan oyun biter

   • Düşman araçları mayın bırakabilir, mayınlara çarparsan oyun biter

🏆 Seviyeler

Oyun 2 farklı seviyeden oluşmaktadır. Her seviyede düşmanların hızı, saldırı sıklığı ve tehlikeler artar. Ayrıca, seviyeye bağlı olarak düşman araçlarının dayanıklılığı da değişir:

	•	Seviye 1: Oyuncu motosikletteyken düşman araçları tek roketle yok edilir.
	•	Seviye 2: Araca geçildiğinde düşman araçlarının dayanıklılığı artar ve 4 roketle yok edilir.

⭐ Güçlendirmeler

	•	Mavi Yıldız: Alındığında oyuncu kısa süreliğine kalkan kazanır. 2 saniye boyunca düşman araçlardan, roketlerden ve mayınlardan etkilenmez.

Hedef: En yüksek skoru elde etmek!

İyi eğlenceler! 🚀